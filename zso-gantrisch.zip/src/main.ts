import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { environment } from './environments/environment';

// Set up global error handlers
window.addEventListener('error', (event) => {
  console.error('Global error caught:', event.error);
  
  // Create a visible error message for users
  const appRoot = document.querySelector('app-root');
  if (appRoot) {
    appRoot.innerHTML = `
      <div style="font-family: sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; text-align: center;">
        <h1 style="color: #FF7F00;">ZSO Gantrisch - Initialization Error</h1>
        <div style="padding: 15px; background-color: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin: 20px 0; text-align: left;">
          <h3>Application failed to initialize</h3>
          <p>Error: ${event.error?.message || event.message || 'Unknown error'}</p>
          <p>The application could not be started due to a technical issue.</p>
        </div>
        <div style="margin-top: 30px;">
          <button onclick="window.location.reload()" style="padding: 10px 20px; background: #FF7F00; color: white; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px;">
            Reload Application
          </button>
          <a href="/assets/angular-debug.html" style="padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px;">
            Run Diagnostics
          </a>
        </div>
      </div>
    `;
  }
});

console.log('🔄 Application bootstrap starting...');
console.log('💻 Environment:', environment.production ? 'Production' : 'Development');

try {
  bootstrapApplication(AppComponent, appConfig)
    .then(() => {
      console.log('✅ Application successfully bootstrapped!');
    })
    .catch(err => {
      console.error('❌ Bootstrap error:', err);
      
      // Display a user-friendly error message
      const appRoot = document.querySelector('app-root');
      if (appRoot) {
        appRoot.innerHTML = `
          <div style="font-family: sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; text-align: center;">
            <h1 style="color: #FF7F00;">ZSO Gantrisch - Initialization Error</h1>
            <div style="padding: 15px; background-color: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin: 20px 0; text-align: left;">
              <h3>Application bootstrapping failed</h3>
              <p>Error: ${err.message || 'Unknown error'}</p>
              <p>Additional info: ${err.stack ? err.stack.split('\n')[0] : 'No additional info'}</p>
            </div>
            <div style="margin-top: 30px;">
              <button onclick="window.location.reload()" style="padding: 10px 20px; background: #FF7F00; color: white; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px;">
                Reload Application
              </button>
              <a href="/assets/angular-debug.html" style="padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px;">
                Run Diagnostics
              </a>
            </div>
          </div>
        `;
      }
    });
} catch (error) {
  console.error('❌ Critical error during bootstrap attempt:', error);
}
