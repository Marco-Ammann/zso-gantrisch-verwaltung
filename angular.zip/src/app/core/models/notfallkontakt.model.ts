export interface Notfallkontakt {
    id: string;
    personId: string;
    name: string;
    beziehung: string;
    telefonnummer: string;
    prioritaet: number; // 1 oder 2
  }