import { Injectable, inject, Renderer2, RendererFactory2 } from '@angular/core';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

import { Person } from '../models/person.model';
import { NotfallkontaktService } from './notfallkontakt.service';
import { TeilnahmeService } from './teilnahme.service';
import { PersonService } from './person.service';
import { AusbildungService } from './ausbildung.service';

@Injectable({
  providedIn: 'root'
})
export class PdfGeneratorService {
  private notfallkontaktService = inject(NotfallkontaktService);
  private teilnahmeService = inject(TeilnahmeService);
  private personService = inject(PersonService);
  private ausbildungService = inject(AusbildungService);
  private renderer: Renderer2;

  constructor(rendererFactory: RendererFactory2) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }

  /**
   * Erstellt EIN PDF pro Person und lädt es herunter.
   */
  async generateKontaktdatenblatt(person: Person): Promise<void> {
    // 1) HTML-Element (DOM) für das PDF bauen
    const pdfElement = await this.buildPdfElementForPerson(person);
    document.body.appendChild(pdfElement);

    try {
      // 2) HTML -> Canvas -> PDF
      const canvas = await html2canvas(pdfElement, { scale: 2, useCORS: true });
      const imgData = canvas.toDataURL('image/png');

      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const ratio = canvas.width / canvas.height;
      const imgHeight = pdfWidth / ratio;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, imgHeight);
      pdf.save(`Kontaktdatenblatt_${person.grunddaten.nachname}_${person.grunddaten.vorname}.pdf`);
    } finally {
      document.body.removeChild(pdfElement);
    }
  }

  /**
   * Erzeugt EINZELNE PDFs für JEDEN Teilnehmer eines Kurses.
   */
  async generateKontaktdatenblaetterFuerKurs(ausbildungId: string): Promise<void> {
    try {
      const ausbildung = await this.ausbildungService.getAusbildungById(ausbildungId);
      if (!ausbildung) {
        console.error('Ausbildung nicht gefunden');
        return;
      }
      const teilnahmen = await this.teilnahmeService.getTeilnahmenByAusbildung(ausbildungId);
      if (teilnahmen.length === 0) {
        console.warn('Keine Teilnehmer für diese Ausbildung gefunden');
        return;
      }

      // Für jeden Teilnehmer einzeln
      for (const t of teilnahmen) {
        const person = await this.personService.getPersonById(t.personId);
        if (person) {
          await this.generateKontaktdatenblatt(person);
        }
      }
    } catch (error) {
      console.error('Fehler beim Generieren der Einzel-PDFs:', error);
      throw error;
    }
  }

  /**
   * Erzeugt EIN gemeinsames PDF für ALLE Teilnehmer eines Kurses.
   */
  async generateKombiniertesKontaktdatenblattFuerKurs(ausbildungId: string): Promise<void> {
    try {
      const ausbildung = await this.ausbildungService.getAusbildungById(ausbildungId);
      if (!ausbildung) {
        console.error('Ausbildung nicht gefunden');
        return;
      }
      const teilnahmen = await this.teilnahmeService.getTeilnahmenByAusbildung(ausbildungId);
      if (teilnahmen.length === 0) {
        console.warn('Keine Teilnehmer für diese Ausbildung gefunden');
        return;
      }

      // Personen sammeln
      const personen = [];
      for (const t of teilnahmen) {
        const person = await this.personService.getPersonById(t.personId);
        if (person) {
          personen.push(person);
        }
      }
      if (personen.length === 0) {
        console.warn('Keine Personen gefunden');
        return;
      }

      // Ein großes PDF erzeugen
      const pdf = new jsPDF('p', 'mm', 'a4');
      for (let i = 0; i < personen.length; i++) {
        if (i > 0) {
          pdf.addPage();
        }
        const person = personen[i];

        // HTML-Element bauen
        const pdfElement = await this.buildPdfElementForPerson(person);
        document.body.appendChild(pdfElement);

        try {
          const canvas = await html2canvas(pdfElement, { scale: 2, useCORS: true });
          const imgData = canvas.toDataURL('image/png');
          const pdfWidth = pdf.internal.pageSize.getWidth();
          const ratio = canvas.width / canvas.height;
          const imgHeight = pdfWidth / ratio;

          pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, imgHeight);
        } finally {
          document.body.removeChild(pdfElement);
        }
      }

      pdf.save(`Kontaktdatenblaetter_${ausbildung.titel}_${ausbildung.jahr}.pdf`);
    } catch (error) {
      console.error('Fehler beim Generieren des kombinierten PDFs:', error);
      throw error;
    }
  }

  /**
   * Baut das HTML-Element (DOM) für EINE Person zusammen.
   * Achtung: asynchron, da wir Notfallkontakte laden.
   */
  private async buildPdfElementForPerson(person: Person): Promise<HTMLElement> {
    const container = this.createBaseContainer();

    // Logo + Titel
    this.buildHeader(container);

    // Addressblock
    this.buildAddressBlock(container, person);

    // Persönliche Daten
    this.buildPersoenlicheDaten(container, person);

    // Zivilschutz-Daten
    this.buildZivilschutzDaten(container, person);

    // Notfallkontakte
    await this.buildNotfallkontakteSection(container, person);

    // Berufliche Infos
    this.buildBeruflicheInfos(container, person);

    // Persönliche Infos (Allergien, etc.)
    this.buildPersoenlicheInfos(container, person);

    // Metadaten (optional)
    this.buildMetadatenSection(container, person);

    // Footer
    this.buildFooter(container);

    return container;
  }

  /**
   * Basiscontainer fürs PDF
   */
  private createBaseContainer(): HTMLElement {
    const div = this.renderer.createElement('div');
    this.renderer.setStyle(div, 'position', 'absolute');
    this.renderer.setStyle(div, 'left', '-9999px');
    this.renderer.setStyle(div, 'top', '0');
    this.renderer.setStyle(div, 'width', '210mm');
    this.renderer.setStyle(div, 'padding', '20mm');
    this.renderer.setStyle(div, 'background', 'white');
    this.renderer.setStyle(div, 'font-family', 'Arial, sans-serif');
    return div;
  }

  private buildHeader(parent: HTMLElement): void {
    const headerDiv = this.renderer.createElement('div');
    this.renderer.setStyle(headerDiv, 'display', 'flex');
    this.renderer.setStyle(headerDiv, 'justify-content', 'space-between');
    this.renderer.setStyle(headerDiv, 'align-items', 'center');
    this.renderer.setStyle(headerDiv, 'margin-bottom', '15mm');

    // Logo (Pfad anpassen)
    const logoImg = this.renderer.createElement('img');
    this.renderer.setAttribute(logoImg, 'src', 'assets/logo_lang.png');
    this.renderer.setStyle(logoImg, 'height', '15mm');
    this.renderer.appendChild(headerDiv, logoImg);

    // Überschrift
    const title = this.renderer.createElement('h1');
    this.renderer.setStyle(title, 'font-size', '20px');
    this.renderer.setStyle(title, 'margin', '0');
    this.renderer.appendChild(title, this.renderer.createText('Kontaktdatenblatt'));
    this.renderer.appendChild(headerDiv, title);

    this.renderer.appendChild(parent, headerDiv);
  }

  /**
   * Block: Herr/Frau, Name, Adresse
   */
  private buildAddressBlock(parent: HTMLElement, person: Person): void {
    const block = this.renderer.createElement('div');
    this.renderer.setStyle(block, 'margin-bottom', '15mm');

    // Beispielhaft "Herr" (oder aus Person-Objekt, falls du dort ein Feld "anrede" hast)
    const anredeP = this.renderer.createElement('p');
    this.renderer.appendChild(anredeP, this.renderer.createText('Herr'));
    this.renderer.appendChild(block, anredeP);

    // Name
    const nameP = this.renderer.createElement('p');
    this.renderer.appendChild(
      nameP,
      this.renderer.createText(`${person.grunddaten.nachname} ${person.grunddaten.vorname}`)
    );
    this.renderer.appendChild(block, nameP);

    // Strasse
    const strasseP = this.renderer.createElement('p');
    this.renderer.appendChild(strasseP, this.renderer.createText(person.kontaktdaten.strasse || ''));
    this.renderer.appendChild(block, strasseP);

    // PLZ / Ort
    const ortP = this.renderer.createElement('p');
    this.renderer.appendChild(
      ortP,
      this.renderer.createText(`${person.kontaktdaten.plz} ${person.kontaktdaten.ort}`)
    );
    this.renderer.appendChild(block, ortP);

    this.renderer.appendChild(parent, block);
  }

  /**
   * Persönliche Daten (Geburtsdatum, Mail, Telefon, ...)
   */
  private buildPersoenlicheDaten(parent: HTMLElement, person: Person): void {
    const section = this.createSection('Persönliche Daten');
    const table = this.createTableElement();

    this.addRow(table, 'Geburtsdatum', this.formatDate(person.grunddaten.geburtsdatum));
    this.addRow(table, 'E-Mail', person.kontaktdaten.email || '-');
    this.addRow(table, 'Telefon Festnetz', person.kontaktdaten.telefonFestnetz || '-');
    this.addRow(table, 'Telefon Mobil', person.kontaktdaten.telefonMobil || '-');
    this.addRow(table, 'Telefon Geschäftlich', person.kontaktdaten.telefonGeschaeftlich || '-');

    this.renderer.appendChild(section, table);
    this.renderer.appendChild(parent, section);
  }

  /**
   * Zivilschutz-Daten (grad, funktion, grundausbildung, einteilung, zusatzausbildungen, status)
   */
  private buildZivilschutzDaten(parent: HTMLElement, person: Person): void {
    const section = this.createSection('Zivilschutz');
    const table = this.createTableElement();

    this.addRow(table, 'Grad', person.grunddaten.grad);
    this.addRow(table, 'Funktion', person.grunddaten.funktion);

    // Grundausbildung (z.B. Jahr)
    this.addRow(table, 'Grundausbildung (Jahr)', person.zivilschutz.grundausbildung || '-');

    // Einteilung
    const einteilung = `Zug ${person.zivilschutz.einteilung.zug}${
      person.zivilschutz.einteilung.gruppe ? ', Gruppe ' + person.zivilschutz.einteilung.gruppe : ''
    }`;
    this.addRow(table, 'Einteilung', einteilung);

    // Zusatzausbildungen
    const zusatz = person.zivilschutz.zusatzausbildungen?.length
      ? person.zivilschutz.zusatzausbildungen.join(', ')
      : '-';
    this.addRow(table, 'Zusatzausbildungen', zusatz);

    // Status (aktiv/inaktiv/neu)
    this.addRow(table, 'Status', person.zivilschutz.status);

    this.renderer.appendChild(section, table);
    this.renderer.appendChild(parent, section);
  }

  /**
   * Notfallkontakte laden und darstellen
   */
  private async buildNotfallkontakteSection(parent: HTMLElement, person: Person): Promise<void> {
    const section = this.createSection('Notfallkontakte');
    const table = this.createTableElement();

    try {
      const notfallkontakte = await this.notfallkontaktService.getKontakteForPerson(person.id);
      if (notfallkontakte && notfallkontakte.length > 0) {
        notfallkontakte.sort((a, b) => a.prioritaet - b.prioritaet);

        notfallkontakte.forEach((kontakt, idx) => {
          // Überschrift z.B. "1. Notfallkontakt"
          this.addRow(table, `${idx + 1}. Notfallkontakt:`, '', false);

          // Nummer
          this.addRow(table, 'Notfallnummer', kontakt.telefonnummer || '-');
          // Name
          this.addRow(table, 'Name des Notfallkontakts', kontakt.name || '-');
          // Beziehung
          this.addRow(table, 'Bezug zu Kontakt', kontakt.beziehung || '-');
        });
      } else {
        this.addRow(table, 'Keine Notfallkontakte eingetragen', '');
      }
    } catch (error) {
      console.error('Fehler beim Laden der Notfallkontakte:', error);
      this.addRow(table, 'Fehler beim Laden der Notfallkontakte', '');
    }

    this.renderer.appendChild(section, table);
    this.renderer.appendChild(parent, section);
  }

  /**
   * Berufliche Infos (ausgeübter Beruf, erlernter Beruf, arbeitgeber, ...)
   */
  private buildBeruflicheInfos(parent: HTMLElement, person: Person): void {
    const section = this.createSection('Berufliche Informationen');
    const table = this.createTableElement();

    this.addRow(table, 'Ausgeübter Beruf', person.berufliches.ausgeubterBeruf || '-');
    this.addRow(table, 'Erlernter Beruf', person.berufliches.erlernterBeruf || '-');
    this.addRow(table, 'Arbeitgeber', person.berufliches.arbeitgeber || '-');

    // Zivile Spezialausbildung
    this.addRow(table, 'Zivile Spezialausbildung', person.berufliches.zivileSpezialausbildung || '-');

    // Führerausweis-Kategorie
    const fuehrerausweis = person.berufliches.fuehrerausweisKategorie?.length
      ? person.berufliches.fuehrerausweisKategorie.join(', ')
      : '-';
    this.addRow(table, 'Führerausweis-Kategorie(n)', fuehrerausweis);

    this.renderer.appendChild(section, table);
    this.renderer.appendChild(parent, section);
  }

  /**
   * Persönliche Infos (Sprachen, Allergien, Essgewohnheiten, Besonderheiten)
   */
  private buildPersoenlicheInfos(parent: HTMLElement, person: Person): void {
    const section = this.createSection('Persönliche Informationen');
    const table = this.createTableElement();

    // Sprachkenntnisse
    const sprachen = person.persoenliches.sprachkenntnisse?.length
      ? person.persoenliches.sprachkenntnisse.join(', ')
      : '-';
    this.addRow(table, 'Sprachkenntnisse', sprachen);

    // Allergien
    const allergien = person.persoenliches.allergien?.length
      ? person.persoenliches.allergien.join(', ')
      : '-';
    this.addRow(table, 'Allergien', allergien, true);

    // Essgewohnheiten
    const ess = person.persoenliches.essgewohnheiten?.length
      ? person.persoenliches.essgewohnheiten.join(', ')
      : '-';
    this.addRow(table, 'Essgewohnheiten', ess, true);

    // Blutgruppe
    this.addRow(table, 'Blutgruppe', person.persoenliches.blutgruppe || '-', true);

    // Besonderheiten
    const besonderheiten = person.persoenliches.besonderheiten?.length
      ? person.persoenliches.besonderheiten.join(', ')
      : '-';
    this.addRow(table, 'Besonderheiten', besonderheiten);

    this.renderer.appendChild(section, table);
    this.renderer.appendChild(parent, section);
  }

  /**
   * (Optional) Metadaten anzeigen (letzte Aktualisierung etc.)
   */
  private buildMetadatenSection(parent: HTMLElement, person: Person): void {
    if (!person.metadaten) return;

    const section = this.createSection('Metadaten');
    const table = this.createTableElement();

    // letzteAktualisierung
    this.addRow(table, 'Letzte Aktualisierung', this.formatDate(person.metadaten.letzteAktualisierung));

    // aktualisiert_von
    this.addRow(table, 'Aktualisiert von', person.metadaten.aktualisiert_von || '-');

    // Optional kannst du noch mehr Felder aus "metadaten" anzeigen,
    // falls es dort mehr Einträge gibt. Du könntest auch ein
    // [key: string]: any durchiterieren, wenn du ALLES anzeigen willst.

    this.renderer.appendChild(section, table);
    this.renderer.appendChild(parent, section);
  }

  /**
   * Footer mit Ort/Datum und Unterschrift
   */
  private buildFooter(parent: HTMLElement): void {
    const footerDiv = this.renderer.createElement('div');
    this.renderer.setStyle(footerDiv, 'display', 'flex');
    this.renderer.setStyle(footerDiv, 'justify-content', 'space-between');
    this.renderer.setStyle(footerDiv, 'margin-top', '30mm');

    const ortDatum = this.renderer.createElement('div');
    this.renderer.setStyle(ortDatum, 'width', '45%');
    this.renderer.setStyle(ortDatum, 'border-top', '1px solid black');
    this.renderer.setStyle(ortDatum, 'padding-top', '5px');
    this.renderer.appendChild(ortDatum, this.renderer.createText('Ort / Datum'));
    this.renderer.appendChild(footerDiv, ortDatum);

    const unterschrift = this.renderer.createElement('div');
    this.renderer.setStyle(unterschrift, 'width', '45%');
    this.renderer.setStyle(unterschrift, 'border-top', '1px solid black');
    this.renderer.setStyle(unterschrift, 'padding-top', '5px');
    this.renderer.appendChild(unterschrift, this.renderer.createText('Unterschrift'));
    this.renderer.appendChild(footerDiv, unterschrift);

    this.renderer.appendChild(parent, footerDiv);
  }

  /**
   * Hilfsmethode: Erzeugt <div> + Überschrift (z.B. "Persönliche Daten")
   */
  private createSection(titleText: string): HTMLElement {
    const section = this.renderer.createElement('div');
    this.renderer.setStyle(section, 'margin-bottom', '15mm');

    const title = this.renderer.createElement('h2');
    this.renderer.setStyle(title, 'font-size', '16px');
    this.renderer.setStyle(title, 'margin-bottom', '5px');
    this.renderer.appendChild(title, this.renderer.createText(titleText));

    this.renderer.appendChild(section, title);
    return section;
  }

  /**
   * Hilfsmethode: Erstellt eine Basis-<table>
   */
  private createTableElement(): HTMLElement {
    const table = this.renderer.createElement('table');
    this.renderer.setStyle(table, 'width', '100%');
    this.renderer.setStyle(table, 'border-collapse', 'collapse');
    return table;
  }

  /**
   * Hilfsmethode: Fügt eine Zeile in eine bestehende Tabelle ein
   */
  private addRow(table: HTMLElement, label: string, value: string, redValue = false): void {
    const row = this.renderer.createElement('tr');

    const labelCell = this.renderer.createElement('td');
    this.renderer.setStyle(labelCell, 'width', '40%');
    this.renderer.setStyle(labelCell, 'border', '1px solid #000');
    this.renderer.setStyle(labelCell, 'padding', '5px');
    this.renderer.setStyle(labelCell, 'font-weight', 'bold');
    this.renderer.appendChild(labelCell, this.renderer.createText(label));

    const valueCell = this.renderer.createElement('td');
    this.renderer.setStyle(valueCell, 'width', '60%');
    this.renderer.setStyle(valueCell, 'border', '1px solid #000');
    this.renderer.setStyle(valueCell, 'padding', '5px');
    if (redValue) {
      this.renderer.setStyle(valueCell, 'color', '#cc0000');
      this.renderer.setStyle(valueCell, 'font-weight', 'bold');
    }
    this.renderer.appendChild(valueCell, this.renderer.createText(value));

    this.renderer.appendChild(row, labelCell);
    this.renderer.appendChild(row, valueCell);
    this.renderer.appendChild(table, row);
  }

  /**
   * Datum formatieren (de-CH)
   */
  private formatDate(date: any): string {
    if (!date) return '-';
    try {
      if (typeof date.toDate === 'function') {
        return date.toDate().toLocaleDateString('de-CH');
      }
      return new Date(date).toLocaleDateString('de-CH');
    } catch {
      return '-';
    }
  }
}
