import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatPaginatorModule } from '@angular/material/paginator';

import {
  AusbildungService,
  TeilnahmeService,
  PersonService,
  PdfGeneratorService
} from '../../../core/services';
import { AuthService } from '../../../auth/services/auth.service';
import { Ausbildung } from '../../../core/models/ausbildung.model';
import { Ausbildungsteilnahme } from '../../../core/models/teilnahme.model';
import { Person } from '../../../core/models/person.model';
import { ConfirmDialogComponent } from '../../../shared/ui/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-ausbildung-detail',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatTableModule,
    MatTooltipModule,
    MatDialogModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatPaginatorModule
  ],
  templateUrl: './ausbildung-detail.component.html',
  styleUrls: ['./ausbildung-detail.component.scss']
})
export class AusbildungDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private ausbildungService = inject(AusbildungService);
  private teilnahmeService = inject(TeilnahmeService);
  private personService = inject(PersonService);
  private authService = inject(AuthService);
  private dialog = inject(MatDialog);
  private snackBar = inject(MatSnackBar);
  private pdfService = inject(PdfGeneratorService);

  // Rechte
  canEdit = this.authService.canEdit;
  canDelete = this.authService.canDelete;

  // Zustand
  ausbildung = signal<Ausbildung | null>(null);
  teilnahmen = signal<Ausbildungsteilnahme[]>([]);
  personen = signal<Person[]>([]);
  isLoading = signal(true);
  loadingTeilnahmen = signal(false);

  // Tabellen-Spalten
  displayedColumns: string[] = ['person', 'datum', 'status', 'bemerkung', 'aktionen'];

  /**
   * computed-Signal: dataSource
   * Dieses Array wird bei Änderungen automatisch neu berechnet,
   * wir übergeben es im Template als dataSource().
   */
  dataSource = computed(() => {
    return this.teilnahmen().map(teilnahme => {
      const person = this.personen().find(p => p.id === teilnahme.personId);
      return {
        ...teilnahme,
        personName: person
          ? `${person.grunddaten.grad} ${person.grunddaten.nachname} ${person.grunddaten.vorname}`
          : 'Unbekannt'
      };
    });
  });

  ausbildungId: string | null = null;

  async ngOnInit(): Promise<void> {
    // Routen-Parameter holen
    this.route.paramMap.subscribe(async params => {
      const id = params.get('id');
      if (id) {
        this.ausbildungId = id;
        await this.loadAusbildung(id);
        await this.loadTeilnahmen(id);
      } else {
        this.showSnackBar('Keine Ausbildungs-ID gefunden');
        this.router.navigate(['/ausbildungen']);
      }
    });
  }

  private async loadAusbildung(id: string): Promise<void> {
    this.isLoading.set(true);
    try {
      const ausbildung = await this.ausbildungService.getAusbildungById(id);
      this.ausbildung.set(ausbildung);
      if (!ausbildung) {
        this.showSnackBar('Ausbildung nicht gefunden');
        this.router.navigate(['/ausbildungen']);
      }
    } catch (error) {
      console.error('Fehler beim Laden der Ausbildung:', error);
      this.showSnackBar('Fehler beim Laden der Ausbildungsdetails');
    } finally {
      this.isLoading.set(false);
    }
  }

  private async loadTeilnahmen(ausbildungId: string): Promise<void> {
    this.loadingTeilnahmen.set(true);
    try {
      // Personen laden, falls noch nicht
      if (this.personen().length === 0) {
        await this.personService.loadPersonen();
        this.personen.set(this.personService.personen());
      }

      const teilnahmen = await this.teilnahmeService.getTeilnahmenByAusbildung(ausbildungId);
      this.teilnahmen.set(teilnahmen);
      // dataSource wird von uns nicht mehr manuell upgedatet,
      // da es ein computed-Signal ist.
    } catch (error) {
      console.error('Fehler beim Laden der Teilnahmen:', error);
      this.showSnackBar('Fehler beim Laden der Teilnahmen');
    } finally {
      this.loadingTeilnahmen.set(false);
    }
  }

  editAusbildung(): void {
    if (this.ausbildungId) {
      this.router.navigate(['/ausbildungen', this.ausbildungId, 'bearbeiten']);
    }
  }

  deleteAusbildung(): void {
    const currentAusbildung = this.ausbildung();
    if (!currentAusbildung) return;

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'Ausbildung löschen',
        message: `Möchten Sie die Ausbildung "${currentAusbildung.titel}" wirklich löschen?`,
        confirmText: 'Löschen',
        cancelText: 'Abbrechen'
      }
    });

    dialogRef.afterClosed().subscribe(async result => {
      if (result && this.ausbildungId) {
        try {
          await this.ausbildungService.deleteAusbildung(this.ausbildungId);
          this.showSnackBar('Ausbildung erfolgreich gelöscht');
          this.router.navigate(['/ausbildungen']);
        } catch (error) {
          console.error('Fehler beim Löschen der Ausbildung:', error);
          this.showSnackBar('Fehler beim Löschen der Ausbildung');
        }
      }
    });
  }

  erfasseTeilnahme(): void {
    if (this.ausbildungId) {
      this.router.navigate(['/ausbildungen/teilnahmen', this.ausbildungId]);
    }
  }

  deleteTeilnahme(teilnahme: Ausbildungsteilnahme & { personName: string }): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'Teilnahme löschen',
        message: `Möchten Sie die Teilnahme von ${teilnahme.personName} wirklich löschen?`,
        confirmText: 'Löschen',
        cancelText: 'Abbrechen'
      }
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (result) {
        try {
          await this.teilnahmeService.deleteTeilnahme(teilnahme.id);
          this.showSnackBar('Teilnahme erfolgreich gelöscht');

          if (this.ausbildungId) {
            // Lade neu
            await this.loadTeilnahmen(this.ausbildungId);
          }
        } catch (error) {
          console.error('Fehler beim Löschen der Teilnahme:', error);
          this.showSnackBar('Fehler beim Löschen der Teilnahme');
        }
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/ausbildungen']);
  }

  /**
   * PDFs generieren (einzeln oder kombiniert)
   */
  async generatePdfsForAllParticipants(): Promise<void> {
    if (!this.ausbildungId) return;

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'Kontaktdatenblätter generieren',
        message: 'Möchten Sie ein kombiniertes PDF oder einzelne PDFs für jeden Teilnehmer erstellen?',
        confirmText: 'Kombiniertes PDF',
        cancelText: 'Einzelne PDFs'
      }
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!this.ausbildungId) return;

      try {
        this.showSnackBar('Erstelle PDF(s), bitte warten...');
        const ausbildung = await this.ausbildungService.getAusbildungById(this.ausbildungId);

        if (result === true) {
          await this.pdfService.generateKombiniertesKontaktdatenblattFuerKurs(this.ausbildungId);
          this.showSnackBar(`Kombiniertes PDF für "${ausbildung?.titel}" erstellt`);
        } else if (result === false) {
          await this.pdfService.generateKontaktdatenblaetterFuerKurs(this.ausbildungId);
          this.showSnackBar(`Einzelne PDFs für "${ausbildung?.titel}" erstellt`);
        }
      } catch (error) {
        console.error('Fehler beim Generieren der PDFs:', error);
        this.showSnackBar('Fehler beim Generieren der PDFs');
      }
    });
  }

  formatStatus(status: string): string {
    const statusMap: Record<string, string> = {
      'teilgenommen': 'Teilgenommen',
      'nicht teilgenommen': 'Nicht teilgenommen',
      'dispensiert': 'Dispensiert'
    };
    return statusMap[status] || status;
  }

  formatDate(date: any): string {
    if (!date) return '-';
    try {
      if (date && typeof date.toDate === 'function') {
        return date.toDate().toLocaleDateString('de-CH');
      }
      return new Date(date).toLocaleDateString('de-CH');
    } catch (error) {
      console.error('Fehler bei der Datumsformatierung:', error);
      return '-';
    }
  }

  private showSnackBar(message: string): void {
    this.snackBar.open(message, 'Schließen', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom'
    });
  }
}
