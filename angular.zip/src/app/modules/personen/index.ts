// src/app/modules/personen/index.ts
export * from './personen-liste/personen-liste.component';
export * from './person-detail/person-detail.component';
export * from './person-form/person-form.component';
export * from './notfallkontakte/notfallkontakte.component';
export * from './notfallkontakte/kontakt-dialog/kontakt-dialog.component';
export * from './personen.routes';