export const environment = {
    production: false,
    firebase: {
        projectId: 'zso-gantrisch-verwaltung',
        appId: '1:177544181049:web:0144e7e882ac3c443424e8',
        storageBucket: 'zso-gantrisch-verwaltung.firebasestorage.app',
        apiKey: 'AIzaSyAOaY0iUTYfQDolJjeI35jKZw8n34qCfzM',
        authDomain: 'zso-gantrisch-verwaltung.firebaseapp.com',
        messagingSenderId: '177544181049',
        measurementId: 'G-QZDLMK6PRR',
    }
  };